﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using student.Models;
using System.Data.Entity;
using System.Data;

namespace student.Controllers
{
    public class SignController : Controller
    {
        // GET: Sign
        public ActionResult Index()
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Signs.ToList());
            }
        }
                

        // GET: Sign/Details/5
        public ActionResult Details(int id)
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Signs.Where(x=>x.id==id).FirstOrDefault());
            }
                
        }

        // GET: Sign/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Sign/Create
        [HttpPost]
        public ActionResult Create(Sign it)
        {
            try
            {
                // TODO: Add insert logic here
                using (DbModels db = new DbModels())
                {
                    db.Signs.Add(it);
                    db.SaveChanges();
                }
                    return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Sign/Edit/5
        public ActionResult Edit(int id)
        {
            using (DbModels db = new DbModels())
            {
                return View(db.Signs.Where(x => x.id == id).FirstOrDefault());
            }
        }

        // POST: Sign/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Sign it)
        {
            try
            {
                // TODO: Add update logic here
                using (DbModels db = new DbModels())
                {
                    db.Entry(it).State = EntityState.Modified;
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    
       
        
    }
}
