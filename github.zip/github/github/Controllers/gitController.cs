﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace github.Controllers
{
    public class gitController : Controller
    {
        // GET: git
        public ActionResult Index()
        {
            return View();
        }
    }
}